import boto3
from botocore.exceptions import ClientError
import datetime
import json

iam_client = boto3.client('iam')
secrets_manager = boto3.client('secretsmanager')

def list_access_key(user, days_filter, status_filter):
    keydetails = iam_client.list_access_keys(UserName=user)
    key_details = {}
    user_iam_details = []

    for keys in keydetails['AccessKeyMetadata']:
        if (days := time_diff(keys['CreateDate'])) >= days_filter and keys['Status'] == status_filter:
            key_details['UserName'] = keys['UserName']
            key_details['AccessKeyId'] = keys['AccessKeyId']
            key_details['days'] = days
            key_details['status'] = keys['Status']
            user_iam_details.append(key_details)
            key_details = {}
    return user_iam_details


def time_diff(keycreatedtime):
    now = datetime.datetime.now(datetime.timezone.utc)
    diff = now - keycreatedtime
    return diff.days


def create_key(username, access_key):
    access_key_metadata = iam_client.create_access_key(UserName=username)
    access_key = access_key_metadata['AccessKey']['AccessKeyId']
    secret_key = access_key_metadata['AccessKey']['SecretAccessKey']
    print(f"Access key {access_key} and secret key are created and stored in Secrets Manager")
    secret_name = f'{username}-access-keys/{access_key}'  # Unique secret name for each access key
    secrets_manager.create_secret(
        Name=secret_name,
        SecretString=json.dumps({'access_key': access_key, 'secret_key': secret_key})
    )


def disable_key(access_key, username):
    try:
        iam_client.update_access_key(UserName=username, AccessKeyId=access_key, Status="Inactive")
        print(f"Access key {access_key} has been disabled.")
    except ClientError as e:
        print(f"The access key with id {access_key} cannot be found")


def delete_key(access_key, username):
    try:
        iam_client.delete_access_key(UserName=username, AccessKeyId=access_key)
        print(f"Access key {access_key} has been deleted.")
    except ClientError as e:
        print(f"The access key with id {access_key} cannot be found")

def handler(event, context):
    details = iam_client.list_users(MaxItems=300)
    users = details['Users']
    for user in users:
        username = user['UserName']
        user_iam_details = list_access_key(user=username, days_filter=0, status_filter='Active')
        for access_key in user_iam_details:
            disable_key(access_key=access_key['AccessKeyId'], username=username)
            delete_key(access_key=access_key['AccessKeyId'], username=username)
            create_key(username=username, access_key=access_key['AccessKeyId'])

    return {
        'statusCode': 200,
        'body': 'IAM Key Rotated successfully'
    }
